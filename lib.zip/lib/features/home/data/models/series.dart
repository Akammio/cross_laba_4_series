import 'package:json_annotation/json_annotation.dart';

part 'series.g.dart';

String _summaryFromJson(String? summary) =>
    summary?.replaceAll(RegExp(r'<[^>]*>'), '').trim() ?? '';

String? _imageFromJson(Map<String, dynamic>? json) =>
    json?['original'] as String?;

int? _yearFromJson(String? premiered) =>
    premiered == null ? null : int.tryParse(premiered.substring(0, 4));

String _genresFromJson(List<dynamic> genres) =>
    genres.map((e) => e.toString()).join(', ');

int? _seasonsFromJson(Map<String, dynamic>? embedded) =>
    (embedded?['seasons'] as List?)?.length;

@JsonSerializable()
class Series {
  const Series({
    required this.id,
    required this.title,
    required this.description,
    this.image,
    this.year,
    this.genre = '',
    this.seasons,
  });

  final int id;

  @JsonKey(name: 'name')
  final String title;

  @JsonKey(name: 'summary', fromJson: _summaryFromJson)
  final String description;

  @JsonKey(name: 'image', fromJson: _imageFromJson)
  final String? image;

  @JsonKey(name: 'premiered', fromJson: _yearFromJson)
  final int? year;

  @JsonKey(name: 'genres', fromJson: _genresFromJson)
  final String genre;

  @JsonKey(name: '_embedded', fromJson: _seasonsFromJson)
  final int? seasons;

  factory Series.fromJson(Map<String, dynamic> json) => _$SeriesFromJson(json);

  Map<String, dynamic> toJson() => _$SeriesToJson(this);
}
