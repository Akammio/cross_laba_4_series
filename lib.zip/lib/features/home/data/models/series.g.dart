// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'series.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Series _$SeriesFromJson(Map<String, dynamic> json) => Series(
      id: (json['id'] as num).toInt(),
      title: json['name'] as String,
      description: _summaryFromJson(json['summary'] as String?),
      image: _imageFromJson(json['image'] as Map<String, dynamic>?),
      year: _yearFromJson(json['premiered'] as String?),
      genre: json['genres'] == null
          ? ''
          : _genresFromJson(json['genres'] as List<dynamic>),
      seasons: _seasonsFromJson(json['_embedded'] as Map<String, dynamic>?),
    );

Map<String, dynamic> _$SeriesToJson(Series instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.title,
      'summary': instance.description,
      if (instance.image case final value?) 'image': value,
      if (instance.year case final value?) 'premiered': value,
      'genres': instance.genre,
      if (instance.seasons case final value?) '_embedded': value,
    };
