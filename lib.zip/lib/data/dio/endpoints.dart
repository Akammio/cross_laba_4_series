class Endpoints {
  Endpoints._();

  static const String shows = '/shows';
}
